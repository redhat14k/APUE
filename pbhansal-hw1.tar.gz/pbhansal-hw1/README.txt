bbcp - this program is used to copy a file from source to destination
test.sh file give the following errors: 

Expected failure, but command returned 0:
  /home/pratish58/pratishnew/bbcp file file2
Files '/etc/passwd' and 'file' differ.
Expected failure, but command returned 0:
  /home/pratish58/pratishnew/bbcp file.
 Files '/etc/passwd' and 'file' differ.
 Command timed out, marking as failure:
  /home/pratish58/pratishnew/bbcp big file
 cp: existing: No space left on device
 Expected success, but command failed:
  /home/pratish58/pratishnew/bbcp small existing
 Files 'small' and 'existing' differ.
 ./test.sh: 7/29 tests failed.
